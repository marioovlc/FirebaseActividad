﻿public class Tarea
{
    public string Id { get; set; } // ID único generado por Firebase
    public string Descripcion { get; set; } // Descripción de la tarea
}
