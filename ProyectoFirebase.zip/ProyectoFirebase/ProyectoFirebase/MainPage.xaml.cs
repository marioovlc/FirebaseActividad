﻿using Firebase.Database;
using Firebase.Database.Query;
using System.Collections.ObjectModel;

namespace ProyectoFirebase
{
    public partial class MainPage : ContentPage
    {
        private FirebaseClient firebase; 
        public ObservableCollection<Tarea> Tareas { get; set; } 

        public MainPage()
        {
            InitializeComponent();

            firebase = new FirebaseClient("https://proyecto-mario-1d866-default-rtdb.europe-west1.firebasedatabase.app/");
            Tareas = new ObservableCollection<Tarea>();

            BindingContext = this;

            CargarTareas();
        }

        private async void CargarTareas()
        {
            try
            {
                var firebaseTareas = await firebase
                    .Child("tareas")
                    .OnceAsync<Tarea>();

                Tareas.Clear();
                foreach (var item in firebaseTareas)
                {
                    Tareas.Add(new Tarea { Id = item.Key, Descripcion = item.Object.Descripcion });
                }

                TareaCollectionView.ItemsSource = Tareas;
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", $"No se pudieron cargar las tareas: {ex.Message}", "OK");
            }
        }

        private async void OnAñadirClicked(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(EntryTarea.Text))
            {
                var nuevaTarea = new Tarea { Descripcion = EntryTarea.Text };

                try
                {
                    var respuesta = await firebase.Child("tareas").PostAsync(nuevaTarea);
                    Tareas.Add(new Tarea { Id = respuesta.Key, Descripcion = nuevaTarea.Descripcion });

                    EntryTarea.Text = string.Empty;
                }
                catch (Exception ex)
                {
                    await DisplayAlert("Error", $"No se pudo añadir la tarea: {ex.Message}", "OK");
                }
            }
        }

        private async void OnModificarClicked(object sender, EventArgs e)
        {
            if (TareaCollectionView.SelectedItem is Tarea tareaSeleccionada && !string.IsNullOrWhiteSpace(EntryTarea.Text))
            {
                try
                {
                    tareaSeleccionada.Descripcion = EntryTarea.Text;

                    await firebase.Child("tareas").Child(tareaSeleccionada.Id).PutAsync(tareaSeleccionada);
                    CargarTareas();

                    EntryTarea.Text = string.Empty;
                }
                catch (Exception ex)
                {
                    await DisplayAlert("Error", $"No se pudo modificar la tarea: {ex.Message}", "OK");
                }
            }
        }

        private async void OnEliminarClicked(object sender, EventArgs e)
        {
            if (TareaCollectionView.SelectedItem is Tarea tareaSeleccionada)
            {
                try
                {
                    await firebase.Child("tareas").Child(tareaSeleccionada.Id).DeleteAsync();
                    Tareas.Remove(tareaSeleccionada);
                }
                catch (Exception ex)
                {
                    await DisplayAlert("Error", $"No se pudo eliminar la tarea: {ex.Message}", "OK");
                }
            }
        }

        private void OnTareaSeleccionada(object sender, SelectionChangedEventArgs e)
        {
            if (e.CurrentSelection.FirstOrDefault() is Tarea tareaSeleccionada)
            {
                EntryTarea.Text = tareaSeleccionada.Descripcion;
            }
        }
    }
}
